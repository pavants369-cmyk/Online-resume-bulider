function updatePreview(){
  const map = {
    previewName: document.getElementById('fullName'),
    previewEmail: document.getElementById('email'),
    previewPhone: document.getElementById('phone'),
    previewAddress: document.getElementById('address'),
    previewObjective: document.getElementById('objective'),
    previewEducation: document.getElementById('education'),
    previewSkills: document.getElementById('skills'),
    previewExperience: document.getElementById('experience'),
    previewProjects: document.getElementById('projects'),
    previewCertifications: document.getElementById('certifications')
  };
  Object.keys(map).forEach(id=>{
    const target=document.getElementById(id);
    const source=map[id];
    if(target && source) target.textContent=source.value;
  });
}
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('input,textarea').forEach(el=>el.addEventListener('input',updatePreview));
  updatePreview();
});
