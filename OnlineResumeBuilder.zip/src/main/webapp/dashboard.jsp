<%@ page import="java.util.*" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Dashboard</title><link rel="stylesheet" href="style.css"></head>
<body><div class="nav"><strong>Resume Builder</strong><div><span>Welcome, <%= session.getAttribute("userName") %></span> <a href="logout">Logout</a></div></div>
<div class="container"><div class="card"><h1>My Resumes</h1><a class="btn" href="editor.jsp">Create New Resume</a></div>
<% List<Map<String,Object>> resumes=(List<Map<String,Object>>)request.getAttribute("resumes"); %>
<% if(resumes.isEmpty()) { %><div class="card"><p>No resumes found. Create your first resume.</p></div><% } %>
<% for(Map<String,Object> r:resumes){ %>
<div class="card"><h2><%=r.get("title")%></h2><p><%=r.get("fullName")%></p><p class="muted">Updated: <%=r.get("updatedAt")%></p>
<div class="actions"><a class="btn" href="view?id=<%=r.get("id")%>">View</a><a class="btn secondary" href="editor.jsp?id=<%=r.get("id")%>">Edit</a><a class="btn danger" href="delete?id=<%=r.get("id")%>" onclick="return confirm('Delete this resume?')">Delete</a></div></div>
<% } %></div></body></html>
