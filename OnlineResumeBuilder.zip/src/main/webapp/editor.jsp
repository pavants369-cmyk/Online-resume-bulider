<%@ page import="java.sql.*,com.resume.*" %>
<%
String id=request.getParameter("id");
String title="",fullName="",email="",phone="",address="",objective="",education="",skills="",experience="",projects="",certifications="";
if(id!=null){
  Integer uid=(Integer)session.getAttribute("userId");
  if(uid==null){response.sendRedirect("login.html");return;}
  try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement("SELECT * FROM resumes WHERE id=? AND user_id=?")){
    ps.setInt(1,Integer.parseInt(id));ps.setInt(2,uid);
    try(ResultSet rs=ps.executeQuery()){if(rs.next()){
      title=rs.getString("title");fullName=rs.getString("full_name");email=rs.getString("email");phone=rs.getString("phone");address=rs.getString("address");objective=rs.getString("objective");education=rs.getString("education");skills=rs.getString("skills");experience=rs.getString("experience");projects=rs.getString("projects");certifications=rs.getString("certifications");
    }}}
}
%>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Resume Editor</title><link rel="stylesheet" href="style.css"><script src="script.js" defer></script></head>
<body><div class="nav"><strong>Resume Editor</strong><a href="dashboard">Dashboard</a></div>
<div class="container"><div class="card"><h1>Resume Details</h1><form method="post" action="resume">
<input type="hidden" name="id" value="<%=id==null?"":id%>">
<div class="form-grid">
<div><label>Resume Title</label><input name="title" value="<%=title%>" required></div>
<div><label>Full Name</label><input id="fullName" name="fullName" value="<%=fullName%>" required></div>
<div><label>Email</label><input id="email" name="email" type="email" value="<%=email%>"></div>
<div><label>Phone</label><input id="phone" name="phone" value="<%=phone%>"></div>
<div class="full"><label>Address</label><input id="address" name="address" value="<%=address%>"></div>
<div class="full"><label>Career Objective</label><textarea id="objective" name="objective"><%=objective%></textarea></div>
<div class="full"><label>Education</label><textarea id="education" name="education"><%=education%></textarea></div>
<div class="full"><label>Skills</label><textarea id="skills" name="skills"><%=skills%></textarea></div>
<div class="full"><label>Experience</label><textarea id="experience" name="experience"><%=experience%></textarea></div>
<div class="full"><label>Projects</label><textarea id="projects" name="projects"><%=projects%></textarea></div>
<div class="full"><label>Certifications</label><textarea id="certifications" name="certifications"><%=certifications%></textarea></div>
</div><div class="actions"><button class="btn" type="submit">Save Resume</button><a class="btn secondary" href="dashboard">Cancel</a></div></form></div></div></body></html>
