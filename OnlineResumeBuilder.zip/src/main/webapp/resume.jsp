<%@ page import="java.sql.ResultSet" %>
<%
ResultSet r=(ResultSet)request.getAttribute("resume");
%>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title><%=r.getString("title")%></title><link rel="stylesheet" href="style.css"></head>
<body><div class="nav no-print"><strong>Resume Preview</strong><div><a href="dashboard">Dashboard</a><button class="btn" onclick="window.print()">Print / Save PDF</button></div></div>
<div class="resume">
<h1><%=r.getString("full_name")%></h1>
<p><%=r.getString("email")%> | <%=r.getString("phone")%> | <%=r.getString("address")%></p>
<h2>Career Objective</h2><p><%=r.getString("objective")%></p>
<h2>Education</h2><p><%=r.getString("education")%></p>
<h2>Technical Skills</h2><p><%=r.getString("skills")%></p>
<h2>Experience</h2><p><%=r.getString("experience")%></p>
<h2>Projects</h2><p><%=r.getString("projects")%></p>
<h2>Certifications</h2><p><%=r.getString("certifications")%></p>
</div></body></html>
