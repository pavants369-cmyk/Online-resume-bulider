package com.resume;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/resume")
public class ResumeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.html");
            return;
        }

        int userId = (Integer) session.getAttribute("userId");
        String id = request.getParameter("id");

        String[] fields = {
            "title", "fullName", "email", "phone", "address", "objective",
            "education", "skills", "experience", "projects", "certifications"
        };

        String[] values = new String[fields.length];
        for (int i = 0; i < fields.length; i++) {
            values[i] = request.getParameter(fields[i]);
            if (values[i] == null) values[i] = "";
        }

        try (Connection con = DBConnection.getConnection()) {
            if (id == null || id.isBlank()) {
                String sql = "INSERT INTO resumes(user_id,title,full_name,email,phone,address,objective,education,skills,experience,projects,certifications) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, userId);
                    for (int i = 0; i < values.length; i++) ps.setString(i + 2, values[i]);
                    ps.executeUpdate();
                }
            } else {
                String sql = "UPDATE resumes SET title=?,full_name=?,email=?,phone=?,address=?,objective=?,education=?,skills=?,experience=?,projects=?,certifications=? WHERE id=? AND user_id=?";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    for (int i = 0; i < values.length; i++) ps.setString(i + 1, values[i]);
                    ps.setInt(12, Integer.parseInt(id));
                    ps.setInt(13, userId);
                    ps.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        response.sendRedirect("dashboard");
    }
}
