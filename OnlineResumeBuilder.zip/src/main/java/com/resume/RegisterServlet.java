package com.resume;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (name == null || email == null || password == null ||
            name.isBlank() || email.isBlank() || password.length() < 6) {
            response.sendRedirect("register.html?error=Invalid+input");
            return;
        }

        String sql = "INSERT INTO users(full_name,email,password_hash) VALUES(?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name.trim());
            ps.setString(2, email.trim().toLowerCase());
            ps.setString(3, PasswordUtil.sha256(password));
            ps.executeUpdate();
            response.sendRedirect("login.html?message=Registration+successful");
        } catch (SQLIntegrityConstraintViolationException e) {
            response.sendRedirect("register.html?error=Email+already+registered");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
