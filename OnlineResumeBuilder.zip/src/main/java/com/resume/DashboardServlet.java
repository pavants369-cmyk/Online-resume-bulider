package com.resume;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.html");
            return;
        }

        int userId = (Integer) session.getAttribute("userId");
        List<Map<String, Object>> resumes = new ArrayList<>();

        String sql = "SELECT id,title,full_name,updated_at FROM resumes WHERE user_id=? ORDER BY updated_at DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> row = new HashMap<>();
                    row.put("id", rs.getInt("id"));
                    row.put("title", rs.getString("title"));
                    row.put("fullName", rs.getString("full_name"));
                    row.put("updatedAt", rs.getTimestamp("updated_at"));
                    resumes.add(row);
                }
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        request.setAttribute("resumes", resumes);
        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }
}
