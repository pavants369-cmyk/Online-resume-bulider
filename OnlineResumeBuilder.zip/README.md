# Online Resume Builder

A BCA minor project using HTML, CSS, JavaScript, Java Servlet, and MySQL.

## Requirements
- JDK 17+
- Apache Tomcat 10+
- MySQL 8+
- Eclipse IDE for Enterprise Java/Web Developers or IntelliJ IDEA
- MySQL Connector/J 8.x

## Database setup
Run `database.sql` in MySQL.

Default database:
- Database: `resume_builder`
- User: `root`
- Password: change it in `DBConnection.java`

## Deployment
1. Create a Dynamic Web Project named `OnlineResumeBuilder`.
2. Copy the Java source into `src/main/java/com/resume/`.
3. Copy the web files into `src/main/webapp/`.
4. Add MySQL Connector/J to the project library.
5. Update MySQL username/password in `DBConnection.java`.
6. Add the project to Tomcat 10.
7. Run:
   `http://localhost:8080/OnlineResumeBuilder/`

## Notes
- This project uses `jakarta.servlet.*`, compatible with Tomcat 10+.
- Passwords are stored using SHA-256 for demonstration. For production, use BCrypt/Argon2.
- The print dialog can be used to save the resume as PDF.
